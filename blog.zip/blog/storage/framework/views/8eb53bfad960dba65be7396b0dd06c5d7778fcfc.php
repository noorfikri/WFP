<?php
    $items = array(
        array('type'=>'med','id'=>0,'name'=>'pill','pic'=>'img/item/pill.jpg'),
        array('type'=>'med','id'=>1,'name'=>'tablet','pic'=>'img/item/tablet.jpg'),
        array('type'=>'med','id'=>2,'name'=>'herbal','pic'=>'img/item/herbal.jpg'),
        array('type'=>'equip','id'=>3,'name'=>'mask','pic'=>'img/item/mask.jpg'),
        array('type'=>'equip','id'=>4,'name'=>'syringe','pic'=>'img/item/syringe.jpg')
    );
?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="content">
                <div class="title m-b-md">
                    Catalog
                </div>

                <div class="links">
                    <a href="/catalog/med">Medicines</a>
                    <a href="/catalog/equip">Medical Equipments</a>
                </div>

                <div>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item['type'] == $type): ?>
                            <a href=<?php echo e("/".$item['type']."/".$item['id']); ?>><?php echo e($item['name']); ?></a><br>
                            <img src=<?php echo e($item['pic']); ?>>
                            <br>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\WFP\blog\resources\views/catalog.blade.php ENDPATH**/ ?>